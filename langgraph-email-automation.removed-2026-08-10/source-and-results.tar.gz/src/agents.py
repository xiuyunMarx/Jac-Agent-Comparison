import os

from langchain_core.messages import HumanMessage, SystemMessage, ToolMessage
from langchain_core.prompts import PromptTemplate
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from pydantic import ValidationError

from .prompts import *
from .structure_outputs import *

# The writer may research before drafting; bound so a search-happy model
# cannot loop forever (last turn forces a DraftReply).
MAX_WRITER_TURNS = 4


class Agents:
    """The three agent stages shared with the CrewAI and byLLM implementations:
    categorize (Senior Email Analyst), analyze thread (Email Action Specialist)
    and draft reply (Email Response Writer)."""

    def __init__(self, mailbox):
        self.mailbox = mailbox
        llm = ChatOpenAI(model=os.environ.get("OPENAI_MODEL_NAME", "gpt-4o"))

        categorize_prompt = PromptTemplate(
            template=CATEGORIZE_EMAIL_PROMPT,
            input_variables=["sender", "snippet"],
        )
        self.categorize_email = (
            categorize_prompt |
            llm.with_structured_output(CategorizeEmailOutput)
        )

        analysis_prompt = PromptTemplate(
            template=THREAD_ANALYSIS_PROMPT,
            input_variables=["thread"],
        )
        self.analyze_thread = (
            analysis_prompt |
            llm.with_structured_output(ThreadAnalysis)
        )

        @tool
        def web_search(query: str) -> str:
            """Search the internet for information about a topic and return relevant results."""
            return mailbox.web_search(query)

        self._web_search = web_search
        # tool_choice="required": every turn either researches or submits the draft.
        self._writer_llm = llm.bind_tools(
            [web_search, DraftReply], tool_choice="required"
        )
        self._writer_llm_final = llm.bind_tools(
            [DraftReply], tool_choice="DraftReply"
        )

    def write_draft(self, analysis, thread):
        """Run the writer agent loop; returns a DraftReply, or None if the
        model never produced a valid one (failures land in draft_errors)."""
        messages = [
            SystemMessage(EMAIL_WRITER_PROMPT),
            HumanMessage(EMAIL_WRITER_INPUT.format(
                summary=analysis.summary,
                main_points="\n".join(f"- {p}" for p in analysis.main_points),
                sender_email=analysis.sender_email,
                communication_style=analysis.communication_style,
                thread=thread,
            )),
        ]
        for turn in range(MAX_WRITER_TURNS):
            forced = turn == MAX_WRITER_TURNS - 1
            llm = self._writer_llm_final if forced else self._writer_llm
            response = llm.invoke(messages)
            messages.append(response)

            draft = None
            for call in response.tool_calls:
                if call["name"] == "DraftReply":
                    try:
                        draft = DraftReply.model_validate(call["args"])
                        content = "Draft accepted."
                    except ValidationError as exc:
                        self.mailbox.record_draft_error(str(call["args"]), str(exc))
                        content = f"Error: invalid draft: {exc}"
                    messages.append(ToolMessage(content, tool_call_id=call["id"]))
                else:
                    result = self._web_search.invoke(call["args"])
                    messages.append(ToolMessage(str(result), tool_call_id=call["id"]))
            if draft is not None:
                return draft
        return None
