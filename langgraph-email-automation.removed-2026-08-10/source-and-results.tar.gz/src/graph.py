from langgraph.graph import END, StateGraph

from .nodes import Nodes
from .state import GraphState


class Workflow():
    """Aligned pipeline over the shared mock mailbox: classify -> analyze
    thread -> draft reply, one email at a time.

    Same task as the CrewAI-LangGraph and byLLM implementations; the Gmail
    polling, RAG retrieval and proofreader loop of the original upstream
    version are gone.
    """

    def __init__(self, mailbox):
        workflow = StateGraph(GraphState)
        nodes = Nodes(mailbox)

        workflow.add_node("load_inbox_emails", nodes.load_inbox_emails)
        workflow.add_node("is_email_inbox_empty", nodes.is_email_inbox_empty)
        workflow.add_node("categorize_email", nodes.categorize_email)
        workflow.add_node("analyze_thread", nodes.analyze_thread)
        workflow.add_node("email_writer", nodes.write_draft_email)
        workflow.add_node("create_draft", nodes.create_draft)
        workflow.add_node("skip_email", nodes.skip_email)

        workflow.set_entry_point("load_inbox_emails")
        workflow.add_edge("load_inbox_emails", "is_email_inbox_empty")

        # loop over the inbox until every thread is handled
        workflow.add_conditional_edges(
            "is_email_inbox_empty",
            nodes.check_new_emails,
            {
                "process": "categorize_email",
                "empty": END
            }
        )

        # only IMPORTANT emails get a reply; everything else is skipped
        workflow.add_conditional_edges(
            "categorize_email",
            nodes.route_email_based_on_category,
            {
                "important": "analyze_thread",
                "skip": "skip_email"
            }
        )

        workflow.add_edge("analyze_thread", "email_writer")
        workflow.add_edge("email_writer", "create_draft")
        workflow.add_edge("create_draft", "is_email_inbox_empty")
        workflow.add_edge("skip_email", "is_email_inbox_empty")

        self.app = workflow.compile()
