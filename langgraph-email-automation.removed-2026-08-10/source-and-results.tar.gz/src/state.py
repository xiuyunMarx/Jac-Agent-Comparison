from typing import List
from typing_extensions import TypedDict

from .structure_outputs import DraftReply, ThreadAnalysis


class EmailAbstract(TypedDict):
    """Snippet-level view of one inbox thread, as returned by mailbox.search()."""
    id: str
    threadId: str
    snippet: str
    sender: str


class GraphState(TypedDict, total=False):
    emails: List[EmailAbstract]      # threads still to process; current one is last
    current_email: EmailAbstract
    email_category: str
    thread: str                      # full thread text for the current email
    thread_analysis: ThreadAnalysis
    draft: DraftReply
    drafted: List[dict]              # summary of drafts created this run
