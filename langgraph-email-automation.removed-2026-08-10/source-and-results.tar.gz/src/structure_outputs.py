from enum import Enum
from typing import List
from pydantic import BaseModel, Field


class EmailCategory(str, Enum):
    """Shared classification taxonomy (same enum as the byLLM implementation;
    the CrewAI filter agent expresses the same IMPORTANT-vs-noise split)."""
    IMPORTANT = "IMPORTANT"
    SPAM = "SPAM"
    NEWSLETTER = "NEWSLETTER"
    PROMOTIONAL = "PROMOTIONAL"
    NOTIFICATIONS = "NOTIFICATIONS"
    SOCIAL = "SOCIAL"
    UPDATES = "UPDATES"


class CategorizeEmailOutput(BaseModel):
    category: EmailCategory = Field(
        ...,
        description="Classification of the email based on its snippet and sender."
    )


class ThreadAnalysis(BaseModel):
    summary: str = Field(
        ...,
        description="Concise summary of the email thread's context and overall sentiment."
    )
    main_points: List[str] = Field(
        ...,
        description="The main queries or concerns a reply must address."
    )
    sender_email: str = Field(
        ...,
        description="Bare email address of the person to reply to, e.g. name@example.com."
    )
    communication_style: str = Field(
        ...,
        description="Tone and style used in the thread, e.g. formal, friendly, terse."
    )


class DraftReply(BaseModel):
    """Submit the final reply draft once it is ready to be saved."""
    recipient: str = Field(
        ...,
        description="Bare email address of the person being replied to."
    )
    subject: str = Field(
        ...,
        description="Subject line for the reply, matching the thread's subject."
    )
    message: str = Field(
        ...,
        description="Full body of the reply email, written in the user's voice."
    )
