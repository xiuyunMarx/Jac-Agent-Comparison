import os

from .agents import Agents
from .state import GraphState
from .structure_outputs import EmailCategory


class Nodes:
    def __init__(self, mailbox):
        self.mailbox = mailbox
        self.agents = Agents(mailbox)
        self.my_email = os.environ.get("MY_EMAIL") or mailbox.owner_email

    def load_inbox_emails(self, state: GraphState) -> GraphState:
        """One abstract per unique thread, self-sent mail excluded (mirrors the
        CrewAI check_email node and the byLLM fetch_mail_abstracts)."""
        print("# Checking for new emails")
        seen_threads = set()
        abstracts = []
        for email in self.mailbox.search():
            if email["threadId"] in seen_threads:
                continue
            if self.my_email and self.my_email in email["sender"]:
                continue
            seen_threads.add(email["threadId"])
            abstracts.append({
                "id": email["id"],
                "threadId": email["threadId"],
                "snippet": email["snippet"],
                "sender": email["sender"],
            })
        if abstracts:
            print(f"## {len(abstracts)} new email threads")
        else:
            print("## No new emails")
        return {"emails": abstracts, "drafted": []}

    def is_email_inbox_empty(self, state: GraphState) -> GraphState:
        return state

    def check_new_emails(self, state: GraphState) -> str:
        return "empty" if len(state["emails"]) == 0 else "process"

    def categorize_email(self, state: GraphState) -> GraphState:
        """Senior Email Analyst: classify the email from its snippet and sender."""
        current_email = state["emails"][-1]
        result = self.agents.categorize_email.invoke({
            "sender": current_email["sender"],
            "snippet": current_email["snippet"],
        })
        print(f"### {current_email['threadId']} [{current_email['sender']}] -> {result.category.value}")
        return {
            "email_category": result.category.value,
            "current_email": current_email,
        }

    def route_email_based_on_category(self, state: GraphState) -> str:
        if state["email_category"] == EmailCategory.IMPORTANT.value:
            return "important"
        return "skip"

    def analyze_thread(self, state: GraphState) -> GraphState:
        """Email Action Specialist: pull the full thread and analyze it."""
        thread = self.mailbox.get_thread(state["current_email"]["threadId"])
        analysis = self.agents.analyze_thread.invoke({"thread": thread})
        return {"thread": thread, "thread_analysis": analysis}

    def write_draft_email(self, state: GraphState) -> GraphState:
        """Email Response Writer: draft the reply (with optional web research)."""
        draft = self.agents.write_draft(state["thread_analysis"], state["thread"])
        return {"draft": draft}

    def create_draft(self, state: GraphState) -> GraphState:
        """Capture the draft in the mock mailbox and move to the next email."""
        emails = state["emails"]
        emails.pop()
        draft = state.get("draft")
        if draft is None:
            print("### Writer produced no valid draft; skipping")
            return {"emails": emails}
        self.mailbox.create_draft(draft.recipient, draft.subject, draft.message)
        drafted = state["drafted"]
        drafted.append({"to": draft.recipient, "subject": draft.subject})
        print(f"### Draft created for {draft.recipient}: {draft.subject}")
        return {"emails": emails, "drafted": drafted}

    def skip_email(self, state: GraphState) -> GraphState:
        emails = state["emails"]
        emails.pop()
        return {"emails": emails}
